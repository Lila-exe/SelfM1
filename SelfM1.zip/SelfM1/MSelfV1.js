const discord = require("discord.js");
const client = new discord.Client();
const id = "Votre ID ici";
const prefix = 'Votre préfix ici';
const token = "Votre token ici";

client.on("message", msg => {
  if (msg.author.id === id) {
    if (msg.content.startsWith(prefix + "nick")) {
      if (msg.deletable) msg.delete();
      const klou = msg.content.replace(prefix + 'nick', '')
      msg.member.setNickname(klou)
    }
  }
})
client.on("message", msg => {
  if (msg.author.id === id) {
    if (msg.content.startsWith(prefix + "nick")) {
      if (msg.deletable) msg.delete();
      const klou = msg.content.replace(prefix + 'nick', '')
      const kkd = new discord.RichEmbed()
      .setTitle('Nickname')
      .setDescription('Votre nickname a été mis à jour sous le nom de: ' + klou)
      .setFooter('Selfbot by mokmi')
      .setThumbnail(msg.author.avatarURL)
      msg.channel.send(kkd)
    }
  }
})
client.on("message", msg => {
  if (msg.author.id === id) {
    if (msg.content.startsWith(prefix + "8ball")) {
      if (msg.deletable) msg.delete();
      var sayings = [
        "Yes.",
        "Non.",
        "Oui",
        "Peut-être.",
        "Je ne sais pas.",
        "Sûrement.",
        "Sûrement pas."
      ];
      var result = Math.floor(Math.random() * sayings.length + 0);
      if (result == 1) {
        var jj = msg.content.replace(prefix + "8ball", "");
        const embed = new discord.RichEmbed()
          .setTitle(`${msg.author.username} a demandé: ${jj}`)
          .setDescription("🔮 **Réponse:** Non ")
          .setThumbnail(msg.author.avatarURL)
          .setFooter("Selfbot by Mokmi");
        msg.channel.send({ embed });
      } else if (result == 2) {
        var jj = msg.content.replace(prefix + "8ball", "");
        const embed = new discord.RichEmbed()
          .setTitle(`${msg.author.username} a demandé: ${jj}`)
          .setDescription("🔮 **Réponse:** Oui ")
          .setThumbnail(msg.author.avatarURL)
          .setFooter("Selfbot by Mokmi");
        msg.channel.send({ embed });
      } else if (result == 3) {
        var jj = msg.content.replace(prefix + "$8ball", "");
        const embed = new discord.RichEmbed()
          .setTitle(`${msg.author.username} a demandé: ${jj}`)
          .setDescription("🔮 **Réponse:** Peut-être ")
          .setThumbnail(msg.author.avatarURL)
          .setFooter("Selfbot by Mokmi");
        msg.channel.send({ embed });
      } else if (result == 4) {
        var jj = msg.content.replace(prefix + "$8ball", "");
        const embed = new discord.RichEmbed()
          .setTitle(`${msg.author.username} a demandé: ${jj}`)
          .setDescription("🔮 **Réponse:** Sûrement ")
          .setThumbnail(msg.author.avatarURL)
          .setFooter("Selfbot by Mokmi");
        msg.channel.send({ embed });
      } else if (result == 5) {
        var jj = msg.content.replace(prefix + "$8ball", "");
        const embed = new discord.RichEmbed()
          .setTitle(`${msg.author.username} a demandé: ${jj}`)
          .setDescription("🔮 **Réponse:** Sûrement pas ")
          .setThumbnail(msg.author.avatarURL)
          .setFooter("Selfbot by Mokmi");
        msg.channel.send({ embed });
      } else if (result == 6) {
        var jj = msg.content.replace(prefix + "$8ball", "");
        const embed = new discord.RichEmbed()
          .setTitle(`${msg.author.username} a demandé: ${jj}`)
          .setDescription("🔮 **Réponse:** Je ne sais pas ")
          .setThumbnail(msg.author.avatarURL)
          .setFooter("Selfbot by Mokmi");
        msg.channel.send({ embed });
      }
    }
  }
});
client.on("message", msg => {
  if (msg.author.id === id) {
    if (msg.content.startsWith(prefix + "hug")) {
      if (msg.deletable) msg.delete();
      const user = msg.mentions.users.first();
      if (user) {
        var sayin = [
          "https://media.tenor.com/images/934adba8e5516096e526f955458ec94a/tenor.gif",
          "https://media.tenor.com/images/ca88f916b116711c60bb23b8eb608694/tenor.gif",
          "https://media.tenor.com/images/a9730f44f28d959abb4c5b31edc77de8/tenor.gif",
          "https://media.tenor.com/images/60bca259cb36db34d4be16c5972a5bee/tenor.gif",
          "https://media.tenor.com/images/49dc9058b390fcec0a9ebbe71a2f82af/tenor.gif",
          "https://media.tenor.com/images/ac5a0c47918dece5e69c1cc9fbb416a9/tenor.gif"
        ];
        var result = Math.floor(Math.random() * sayin.length + 0);
        if (result == 1) {
          const embed = new discord.RichEmbed()
            .setTitle("Hug")
            .setDescription(`💖 ${msg.author.username} hug ${user.username}`)

            .setImage(
              "http://giphygifs.s3.amazonaws.com/media/lrr9rHuoJOE0w/giphy.gif"
            )
            .setFooter("Selfbot by Mokmi");
          msg.channel.send({ embed });
        } else if (result == 2) {
          const embed = new discord.RichEmbed()
            .setTitle("Hug")
            .setDescription(`💖 ${msg.author.username} hug ${user.username}`)

            .setImage("https://media.giphy.com/media/qscdhWs5o3yb6/giphy.gif")
            .setFooter("Selfbot by Mokmi");
          msg.channel.send({ embed });
        } else if (result == 3) {
          const embed = new discord.RichEmbed()
            .setTitle("Hug")
            .setDescription(`💖 ${msg.author.username} hug ${user.username}`)

            .setImage("https://media.giphy.com/media/wnsgren9NtITS/giphy.gif")
            .setFooter("Selfbot by Mokmi");
          msg.channel.send({ embed });
        } else if (result == 4) {
          const embed = new discord.RichEmbed()
            .setTitle("Hug")
            .setDescription(`💖 ${msg.author.username} hug ${user.username}`)

            .setImage("https://media.giphy.com/media/fLv2F5rMY2YWk/giphy.gif")
            .setFooter("Selfbot by Mokmi");
          msg.channel.send({ embed });
        } else if (result == 5) {
          const embed = new discord.RichEmbed()
            .setTitle("Hug")
            .setDescription(`💖 ${msg.author.username} hug ${user.username}`)

            .setImage(
              "https://media.giphy.com/media/l2QDM9Jnim1YVILXa/giphy.gif"
            )
            .setFooter("Selfbot by Mokmi");
          msg.channel.send({ embed });
        } else if (result == 6) {
          const embed = new discord.RichEmbed()
            .setTitle("Hug")
            .setDescription(`💖 ${msg.author.username} hug ${user.username}`)

            .setImage("https://media.giphy.com/media/p6ER3TdzHy7Zu/giphy.gif");
          msg.channel.send({ embed });
        } else if (result == 7) {
          const embed = new discord.RichEmbed()
            .setTitle("Hug")
            .setDescription(`💖 ${msg.author.username} hug ${user.username}`)
            .setImage("https://tenor.com/3DyS.gif")
            .setFooter("Selfbot by Mokmi");
          msg.channel.send({ embed });
        }
      }
    }
  }
});
client.on("message", async message => {
  if (message.author.id === id) {
    if (message.content.startsWith(prefix + "vole")) {
message.delete();
var hkkl = new discord.RichEmbed()
.setTitle('*Erreur*')
.setDescription('Vous devez être premium pour effectuer cette commande')
.setFooter('Selfbot by mokmi')
message.channel.send(hkkl)
    }
  }
})
client.on("message", message => {
  if (message.author.id === id) {
    if (message.content.startsWith(prefix + "play")) {
      message.delete();

      var newmsg = message.content.replace(prefix + "play", "");
      try {
        client.user.setPresence({
          game: {
            name: newmsg,
            type: "PLAYING"
          }
        });
      } catch (e) {}
    }
  }
});
client.on("message", message => {
  if (message.author.id === id) {
    if (message.content.startsWith(prefix + "play")) {
      message.delete();

      var newmsg = message.content.replace(prefix + "play", "");
      const embed = new discord.RichEmbed()
        .setTitle("**Jeu**")
        .setDescription(
          "🎮 Vous êtes actuellement en train de jouer à: " +
            newmsg +
            " (*Si vous ne voyez pas votre jeu en status, vérifiez que vous n'avez aucun status personalisé*)"
        )
        .setThumbnail(message.author.avatarURL)
        .setFooter("Selfbot by Mokmi");
      message.channel.send(embed);
    }
  }
});

client.on("message", message => {
  if (message.author.id === id) {
    if (message.content.startsWith(prefix + "stream")) {
      message.delete();

      var newmsge = message.content.replace(prefix + "stream", "");
      try {
        client.user.setPresence({
          game: {
            name: newmsge,
            type: "STREAMING",
            url: "https://www.twitch.tv/monstercat"
          }
        });
      } catch (e) {}
    }
  }
});
client.on("message", message => {
  if (message.author.id === id) {
    if (message.content.startsWith(prefix + "stream")) {
      message.delete();

      var newmsge = message.content.replace(prefix + "stream", "");
      const embed = new discord.RichEmbed()
        .setTitle("**Stream**")
        .setDescription(
          "🎬 Vous êtes actuellement en train de streamer: " +
            newmsge +
            " (*Si vous ne voyez pas votre stream en status, vérifiez que vous n'avez aucun status personalisé*)"
        )
        .setThumbnail(message.author.avatarURL)
        .setFooter("Selfbot by Mokmi");
      message.channel.send(embed);
    }
  }
});
client.on("message", message => {
  if (message.author.id === id) {
    if (message.content.startsWith(prefix + "pp")) {
      message.delete();

      const user = message.mentions.users.first();
      if (user) {
        const embed = new discord.RichEmbed()
          .setTitle("Pp")
          .setDescription(`📜 Voici la photo de profile de ${user.username} !`)
          .setImage(`${user.avatarURL}`)
          .setTimestamp()
          .setFooter("Selfbot by Mokmi");

        message.channel.send({ embed });
      }
    }
  }
});
client.on("message", async message => {
  if (message.author.id === id) {
    if (message.content === prefix + "info") {
      message.delete();
      const embeed = new discord.RichEmbed()
        .setTitle("📖 **Informations**")
        .setThumbnail(message.author.avatarURL)
        .addField("**ID: **", id)
        .addField("**Nom: **", message.author.username)
        .addField("**Préfix: **", prefix)
        .addField("**Date de création: **", message.author.createdAt)
        .addField("**Status actuel: **", message.author.presence.status)
      .addField("**Version: **", '1.0')
      .addField("**Accès: **", 'Non-Premium')
        .setFooter("Selfbot by Mokmi");
      message.channel.send(embeed);
    }
  }
});
client.on("message", message => {
  if (message.author.id === id) {
    if (message.content.startsWith(prefix + "listen")) {
      message.delete();

      var newmsg = message.content.replace(prefix + "listen", "");
      try {
        client.user.setPresence({
          game: {
            name: newmsg,
            type: "LISTENING"
          }
        });
      } catch (e) {}
    }
  }
});
client.on("message", message => {
  if (message.author.id === id) {
    if (message.content.startsWith(prefix + "listen")) {
      message.delete();

      var newmsg = message.content.replace(prefix + "listen", "");
      const embed = new discord.RichEmbed()
        .setTitle("**Écoute**")
        .setDescription(
          "🎧 Vous êtes actuellement en train d'écouter: " +
            newmsg +
            " (*Si vous ne voyez pas votre écoute en status, vérifiez que vous n'avez aucun status personalisé*)"
        )
        .setThumbnail(message.author.avatarURL)
        .setFooter("Selfbot by Mokmi");
      message.channel.send(embed);
    }
  }
});
client.on("message", message => {
  if (message.author.id === id) {
    if (message.content.startsWith(prefix + "watch")) {
      message.delete();

      var newmsg = message.content.replace(prefix + "watch", "");
      try {
        client.user.setPresence({
          game: {
            name: newmsg,
            type: "WATCHING"
          }
        });
      } catch (e) {}
    }
  }
});
client.on("message", message => {
  if (message.author.id === id) {
    if (message.content.startsWith(prefix + "watch")) {
      message.delete();

      var newmsg = message.content.replace(prefix + "watch", "");
      const embed = new discord.RichEmbed()
        .setTitle("**Regarder**")
        .setDescription(
          "💻 Vous êtes actuellement en train de regarder: " +
            newmsg +
            " (*Si vous ne voyez pas votre regard en status, vérifiez que vous n'avez aucun status personalisé*)"
        )
        .setThumbnail(message.author.avatarURL)
        .setFooter("Selfbot by Mokmi");
      message.channel.send(embed);
    }
  }
});
client.on("message", message => {
  if (message.author.id === id) {
    if (message.content.startsWith(prefix + "remove")) {
      message.delete();
      client.user.setActivity(null);
    }
  }
});
client.on("message", message => {
  if (message.author.id === id) {
    if (message.content.startsWith(prefix + "remove")) {
      message.delete();
      const embbb = new discord.RichEmbed()
        .setTitle("Annuler")
        .setThumbnail(message.author.avatarURL)
        .setFooter("Selfbot by Mokmi")
        .setDescription("Votre status à été éffacé avec succès!");
      message.channel.send(embbb);
    }
  }
});
client.on("message", message => {
  if (message.author.id === id) {
    if (message.content === prefix + "help") {
      message.delete();
      const embbbb = new discord.RichEmbed()
        .setTitle("📕 **Help**:")
        .setThumbnail(message.author.avatarURL)
        .setFooter("Selfbot by Mokmi")
        .setDescription("✔️ Veuillez choisir la catégorie voulue: ")
        .addField("🎨" + prefix + "**fun**", "*Toutes les commandes amusantes!*")
        .addField("💡" + prefix + "**utiles**", "*Toutes les commandes utiles!*")
        .addField("🔰" + prefix + "**modération**", "*Toutes les commandes de modération!*")
      .addField("🔧" + prefix + "**botinfo**", "*Important!*")
      .addField("🔪" + prefix + "**raid**", '*Toutes les commandes raid (Premium)*')
        .setImage("https://media.giphy.com/media/ZOGCyj0NW28gg/giphy.gif");
      message.channel.send(embbbb);
    }
  }
});
client.on("message", message => {
  if (message.author.id === id) {
    if (message.content === prefix + "modération") {
      message.delete();
      const h = new discord.RichEmbed()
        .setTitle("🔰 **Commandes modération**")
        .setFooter("Selfbot by Mokmi")
        .setThumbnail(message.author.avatarURL)
        .addField(prefix + "ban (Premium)", "**Déscription**: Banni un utilisateur")
        .addField(prefix + "kick", "**Déscription**: Kick un utilisateur")
        .setImage("https://media.giphy.com/media/OxYBKwc5pLRjq/giphy.gif");
      message.channel.send(h);
    }
  }
});
client.on("message", message => {
  if (message.author.id === id) {
    if (message.content === prefix + "utiles") {
      message.delete();
      const d = new discord.RichEmbed()
        .setTitle("💡 **Commandes utiles**")
        .setFooter("Selfbot by Mokmi")
        .setThumbnail(message.author.avatarURL)
        .addField(prefix + "info", "**Déscription**: Donne les informations du bot")
        .addField(
          prefix + "userinfo",
          "**Déscription**: Donne les informations d'un utilisateur"
        )
        .addField(
          prefix + "stream",
          "**Déscription**: Passe votre status en mode stream"
        )
        .addField(prefix + "play", "**Déscription**: Passe votre status en mode jeu")
        .addField(
          prefix + "watch",
          "**Déscription**: Passe votre status en mode regarde"
        )
        .addField(
          prefix + "listen",
          "**Déscription**: Passe votre status en mode écoute"
        )
        .addField(prefix + "remove", "**Déscription**: Enlève votre status")
        .addField(
          prefix + "pp",
          "**Déscription**: Donne la photo de profile d'un utilisateur"
        )
        .addField(
          prefix + "vole (Premium)",
          "**Déscription**: Vole la photo de profile d'un utilisateur"
        )
        .addField(prefix + "role (Premium)", "**Déscription**: Crée un nouveau rôle")
        .addField(prefix + "channel (Premium)", "**Déscription**: Crée un nouveau channel")
        .addField(prefix + "ping", "**Déscription**: Donne votre ping")
        .addField(
          prefix + "nick",
          "**Déscription**: Change votre nickname dans un serveur"
        )
      .addField(
          prefix + "changelog",
          "**Déscription**: Donne les nouveautés du bot"
        )
      .addField(
          prefix + "serverinfo",
          "**Déscription**: Donne les info du serveur"
        )
        .setImage("https://media.giphy.com/media/s8cZbzC3gTiAo/giphy.gif");
         
      message.channel.send(d);
    }
  }
});
client.on("message", message => {
  if (message.author.id === id) {
    if (message.content === prefix + "fun") {
      message.delete();
      const t = new discord.RichEmbed()
        .setTitle("🎨 **Commandes fun**")
        .setFooter("Selfbot by Mokmi")
        .setThumbnail(message.author.avatarURL)
        .addField(
          prefix + "8ball",
          "**Déscription**: Donne une réponse aléatoire à vos questions"
        )
        .addField(
          prefix + "hug",
          "**Déscription**: Donne un câlin virtuel à une personne"
        )
        .addField(
          prefix + "kiss",
          "**Déscription**: Embrasse virtuellement une personne"
        )
        .addField(
          prefix + "embed",
          "**Déscription**: Envoie un text en embed (" + prefix + "embedblue/red/yellow/purple/green/orange/pink)"
        )
        .addField(prefix + "ddos (Premium)", "**Déscription**: Fake ddos une personne")
        .addField(
          prefix + "token (Premium)",
          "**Déscription**: Récupère un fake token d'un utilisateur"
        )
        .addField(prefix + "veski", "**Déscription**: Veski un utilisateur")
        .addField(
          prefix + "combat",
          "**Déscription**: Défi quelqu'un pour venir se battre"
        )
        .addField(
          prefix + "bontoutou",
          "**Déscription**: Prouve à quelqu'un qu'il n'est qu'un bon toutou"
        )
        .setImage("https://media.giphy.com/media/WovDmuS6blgJi/giphy.gif");
      message.channel.send(t);
    }
  }
});
client.on("message", async message => {
  const usere = message.mentions.users.first();
  if (message.author.id === id) {
    if (message.content.startsWith(prefix + "userinfo")) {
      if (usere) {
        message.delete();
        const embeed = new discord.RichEmbed()
          .setTitle("📖 **Informations sur: **" + usere.username)
          .setThumbnail(usere.avatarURL)
          .addField("**ID: **", usere.id)
          .addField("**Nom: **", usere.username)
          .addField("**Date de création: **", usere.createdAt)
          .addField("**Status actuel: **", usere.presence.status)
          .setFooter("Selfbot by Mokmi");
        message.channel.send(embeed);
      }
    }
  }
});
client.on("message", message => {
  if (message.author.id === id) {
    if (message.content.startsWith(prefix + "channel")) {
      message.delete();
var hkkl = new discord.RichEmbed()
.setTitle('*Erreur*')
.setDescription('Vous devez être premium pour effectuer cette commande')
.setFooter('Selfbot by mokmi')
message.channel.send(hkkl)
    }
  }
});

client.on("message", message => {
  if (message.author.id === id) {
    if (message.content.startsWith(prefix + "role")) {
      message.delete();
   var hkkl = new discord.RichEmbed()
.setTitle('*Erreur*')
.setDescription('Vous devez être premium pour effectuer cette commande')
.setFooter('Selfbot by mokmi')
message.channel.send(hkkl)
    }
  }
})
   
client.on("message", message => {
  if (message.author.id === id) {
    if (message.content === prefix + "ping") {
      message.delete();
      const embey = new discord.RichEmbed()
        .setTitle(" 🏓 **Pong!**")
        .setDescription("Votre ping est de: " + client.ping + " ms!")
        .setThumbnail(message.author.avatarURL)
        .setFooter("Selfbot by Mokmi");
      message.channel.send(embey);
    }
  }
});
client.on("message", message => {
  if (message.author.id === id) {
    if (message.content.startsWith(prefix + "ban")) {
      message.delete();
var hkkl = new discord.RichEmbed()
.setTitle('*Erreur*')
.setDescription('Vous devez être premium pour effectuer cette commande')
.setFooter('Selfbot by mokmi')
message.channel.send(hkkl)
    }
  }
})
client.on("message", async message => {
  if (message.author.id === id) {
    const usereeee = message.mentions.users.first();
    const args = message.content
      .slice(prefix.length)
      .trim()
      .split(/ +/g);
    let member =
      message.mentions.members.first() || message.guild.members.get(args[0]);
    if (message.content.startsWith(prefix + "kick")) {
      message.delete();
      if (member) {
        await member.kick();
        message.channel.send(`${usereeee.username} a été kick avec succès!`);
      }
    }
  }
});
client.on("message", async msg => {
  if (msg.author.id === id) {
    if (msg.content.startsWith(prefix + "kiss")) {
      msg.delete();
      const usertt = msg.mentions.users.first();
      if (usertt) {
        var say = [
          "https://media.tenor.com/images/26aaa1494b424854824019523c7ba631/tenor.gif",
          "https://media.tenor.com/images/68d59bb29d7d8f7895ce385869989852/tenor.gif",
          "https://media.tenor.com/images/4e9c5f7f9a6008c1502e1c12eb5454f9/tenor.gif",
          "https://media.tenor.com/images/f2795e834ff4b9ed3c8ca6e1b21c3931/tenor.gif",
          "https://media.tenor.com/images/1f9175e76488ebf226de305279151752/tenor.gif",
          "https://media.tenor.com/images/9fb52dbfd3b7695ae50dfd00f5d241f7/tenor.gif"
        ];
        var result = Math.floor(Math.random() * say.length + 0);
        if (result == 1) {
          const embed = new discord.RichEmbed()
            .setTitle("Kiss")
            .setDescription(`💓 ${msg.author.username} Kiss ${usertt.username}`)
            .setImage("https://media.giphy.com/media/KH1CTZtw1iP3W/giphy.gif")
            .setFooter("Selfbot by mokmi");
          msg.channel.send({ embed });
        } else if (result == 2) {
          const embed = new discord.RichEmbed()
            .setTitle("Kiss")
            .setDescription(`💓 ${msg.author.username} Kiss ${usertt.username}`)
            .setImage("https://media.giphy.com/media/nyGFcsP0kAobm/giphy.gif")
            .setFooter("Selfbot by mokmi");
          msg.channel.send({ embed });
        } else if (result == 3) {
          const embed = new discord.RichEmbed()
            .setTitle("Kiss")
            .setDescription(`💓 ${msg.author.username} Kiss ${usertt.username}`)
            .setImage("https://media.giphy.com/media/wOtkVwroA6yzK/giphy.gif")
            .setFooter("Selfbot by mokmi");
          msg.channel.send({ embed });
        } else if (result == 4) {
          const embed = new discord.RichEmbed()
            .setTitle("Kiss")
            .setDescription(`💓 ${msg.author.username} Kiss ${usertt.username}`)
            .setImage("https://media.giphy.com/media/Ka2NAhphLdqXC/giphy.gif")
            .setFooter("Selfbot by mokmi");
          msg.channel.send({ embed });
        } else if (result == 5) {
          const embed = new discord.RichEmbed()
            .setTitle("Kiss")
            .setDescription(`💓 ${msg.author.username} Kiss ${usertt.username}`)
            .setImage("https://media.giphy.com/media/KmeIYo9IGBoGY/giphy.gif")
            .setFooter("Selfbot by mokmi");
          msg.channel.send({ embed });
        }
      }
    }
  }
});
client.on("message", async message => {
  if (message.author.id === id) {
    if (message.content.startsWith(prefix + "embedred")) {
      message.delete();

      var dee = message.content.replace(prefix + "embedred", "");
      const embedeeeee = new discord.RichEmbed()
        .setDescription(`${dee}`)
        .setColor(15158332);
      message.channel.send(embedeeeee);
    }
  }
});
client.on("message", async message => {
  if (message.author.id === id) {
    if (message.content.startsWith(prefix + "embedblue")) {
      message.delete();

      var deee = message.content.replace(prefix + "embedblue", "");
      const embedeeeeee = new discord.RichEmbed()
        .setDescription(`${deee}`)
        .setColor(3447003);
      message.channel.send(embedeeeeee);
    }
  }
});
client.on("message", async message => {
  if (message.author.id === id) {
    if (message.content.startsWith(prefix + "embedgreen")) {
      message.delete();

      var deeee = message.content.replace(prefix + "embedgreen", "");
      const embedeeeeeee = new discord.RichEmbed()
        .setDescription(`${deeee}`)
        .setColor(3066993);
      message.channel.send(embedeeeeeee);
    }
  }
});
client.on("message", async message => {
  if (message.author.id === id) {
    if (message.content.startsWith(prefix + "embedorange")) {
      message.delete();

      var deeeee = message.content.replace(prefix + "embedorange", "");
      const embedeeeeeeee = new discord.RichEmbed()
        .setDescription(`${deeeee}`)
        .setColor(15105570);
      message.channel.send(embedeeeeeeee);
    }
  }
});
client.on("message", async message => {
  if (message.author.id === id) {
    if (message.content.startsWith(prefix + "embedpink")) {
      message.delete();

      var deeeeee = message.content.replace(prefix + "embedpink", "");
      const embedeeeeeeeee = new discord.RichEmbed()
        .setDescription(`${deeeeee}`)
        .setColor(16580705);
      message.channel.send(embedeeeeeeeee);
    }
  }
});
client.on("message", async message => {
  if (message.author.id === id) {
    if (message.content.startsWith(prefix + "embedpurple")) {
      message.delete();
      var deeeeeee = message.content.replace(prefix + "embedpurple", "");
      const embedeeeeeeeeee = new discord.RichEmbed()
        .setDescription(`${deeeeeee}`)
        .setColor(10181046);
      message.channel.send(embedeeeeeeeeee);
    }
  }
});
client.on("message", async message => {
  if (message.author.id === id) {
    if (message.content.startsWith(prefix + "embedyellow")) {
      message.delete();
      var deeeeeee = message.content.replace(prefix + "embedyellow", "");
      const embedeeeeeeeeee = new discord.RichEmbed()
        .setDescription(`${deeeeeee}`)
        .setColor(15844367);
      message.channel.send(embedeeeeeeeeee);
    }
  }
});
client.on("message", async message => {
  if (message.author.id === id) {
    if (message.content.startsWith(prefix + "ddos")) {
      message.delete();
var hkkl = new discord.RichEmbed()
.setTitle('*Erreur*')
.setDescription('Vous devez être premium pour effectuer cette commande')
.setFooter('Selfbot by mokmi')
message.channel.send(hkkl)
    }
  }
})
client.on("message", async msg => {
  if (msg.author.id === id) {
    if (msg.content.startsWith(prefix + "token")) {
      msg.delete();
var hkkl = new discord.RichEmbed()
.setTitle('*Erreur*')
.setDescription('Vous devez être premium pour effectuer cette commande')
.setFooter('Selfbot by mokmi')
msg.channel.send(hkkl)
    }
  }
})
client.on("message", message => {
  if (message.author.id == id) {
    if (message.content === prefix + "veski") {
      message.delete();
      const embed = new discord.RichEmbed()
        .setTitle(`✈️ **${message.author.username} Veski**`)
        .setDescription(message.author.username + " Décide de veski!")
        .setImage("https://media.giphy.com/media/3o7ZetIsjtbkgNE1I4/giphy.gif")
        .setFooter("Selfbot by mokmi");
      message.channel.send({ embed });
    }
  }
});
client.on("message", message => {
  const hhhh = message.mentions.users.first();
  if (message.author.id == id) {
    if (message.content.startsWith(prefix + "bontoutou")) {
      if (hhhh) {
        message.delete();

        const embed = new discord.RichEmbed()
          .setTitle(`🐶 **Bon toutou**`)
          .setDescription(hhhh.username + " Est un bon toutou!")
          .setImage("https://t1.daumcdn.net/cfile/tistory/254EA84C580C2BA218")
          .setFooter("Selfbot by mokmi");
        message.channel.send({ embed });
      }
    }
  }
});
client.on("message", message => {
  const hhhhh = message.mentions.users.first();
  if (message.author.id == id) {
    if (message.content.startsWith(prefix + "combat")) {
      if (hhhhh) {
        message.delete();

        const embed = new discord.RichEmbed()
          .setTitle(`💣 **Duel**`)
          .setDescription(
            message.author.username + " Propose un duel à " + hhhhh.username
          )
          .setImage(
            "https://media.giphy.com/media/3oEjI1erPMTMBFmNHi/giphy.gif"
          )
          .setFooter("Selfbot by mokmi");
        message.channel.send({ embed });
      }
    }
  }
});
client.on("message", message => {
  if (message.author.id === id) {
    if (message.content === prefix + "changelog") {
      message.delete()
      const y = new discord.RichEmbed()
      .setTitle('**CHANGELOGS**')
      .setDescription('Voici les logs récentes du bot: ')
      .addField('*Jeudi, 26 mars 2020*', "**Sortie officiel du bot et de l'option premium!**")
      .setFooter('Selebot by mokmi')
      message.channel.send(y)
    }
  }
})
client.on("message", message => {
  if (message.author.id === id) {
    if (message.content === prefix + 'botinfo') {
      message.delete()
      const x = new discord.RichEmbed()
      .setTitle('**Comment obtenir le bot?**')
      .setDescription('*Le bot est complètement gratuit pour tout le monde mais avec des accès limités. Quelques commandes sont réservées aux membres premium. Le prix du premium est de 1 euro paypal.*')
      .setFooter('Selebot by mokmi')
      message.channel.send(x)
      }
  }
})
client.on("message", message => {
  if (message.author.id === id) {
    if (message.content === prefix + "raid") {
      message.delete();
      const oo = new discord.RichEmbed()
        .setTitle("🔪 **Commandes raid (Premium)**")
      .setDescription('**Pour effectuer les commandes raid, vous devez avoir des permissions sur le serveur ciblé**')
        .setFooter("Selfbot by Mokmi")
        .setThumbnail(message.author.avatarURL)
        .addField(
          prefix + "delrole",
          "**Déscription**: Supprime les rôles d'un serveur"
        )
        .addField(
          prefix + "banall",
          "**Déscription**: Banni tout le monde du serveur"
        )
        .addField(
          prefix + "delc",
          "**Déscription**: Supprime tous les salons du serveur"
        )
       .addField(
          prefix + "rename",
          "**Déscription**: Renomme le serveur comme vous le voulez"
        )
      .setImage('https://media.giphy.com/media/vTCYFpfPZ9m5a/giphy.gif')
      message.channel.send(oo)
      }
  }
})
client.on("message", message => {
  if (message.author.id === id) {
    if (message.content === prefix + "delc") {
      message.delete();
var hkkl = new discord.RichEmbed()
.setTitle('*Erreur*')
.setDescription('Vous devez être premium pour effectuer cette commande')
.setFooter('Selfbot by mokmi')
message.channel.send(hkkl)
    }
  }
})
client.on("message", message => {
  if (message.author.id === id) {
    if (message.content === prefix + "banall") {
      message.delete();
var hkkl = new discord.RichEmbed()
.setTitle('*Erreur*')
.setDescription('Vous devez être premium pour effectuer cette commande')
.setFooter('Selfbot by mokmi')
message.channel.send(hkkl)
       }
    }
  })

client.on("message", msg => {
  if (msg.author.id === id) {
  if (msg.content === prefix + "delrole") {
    msg.delete();
    var hkkl = new discord.RichEmbed()
.setTitle('*Erreur*')
.setDescription('Vous devez être premium pour effectuer cette commande')
.setFooter('Selfbot by mokmi')
msg.channel.send(hkkl)
  }
  }
});
client.on("message", msg => {
  if (msg.author.id === id) {
  if (msg.content.startsWith(prefix + "rename")){
    msg.delete()
var hkkl = new discord.RichEmbed()
.setTitle('*Erreur*')
.setDescription('Vous devez être premium pour effectuer cette commande')
.setFooter('Selfbot by mokmi')
msg.channel.send(hkkl)
  }
  }
})
client.on("message", async message => {
  if (message.author.id === id) {
    if (message.content === prefix + "serverinfo") {
        message.delete();
    try{
        const embeeed = new discord.RichEmbed()
          .setTitle("📖 **Informations sur: **" + message.guild.name)
        .setThumbnail(message.guild.iconURL)
          .addField("**ID: **", message.guild.id)
          .addField("**Nom: **", message.guild.name)
          .addField("**Date de création: **", message.guild.createdAt)
          .setFooter("Selfbot by Mokmi")
        message.channel.send(embeeed);
    }catch(e){
  }
    }
}
})
client.login(token);
