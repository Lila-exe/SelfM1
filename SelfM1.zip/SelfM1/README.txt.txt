﻿Merci d'avoir téléchargé MSelfV1! Pour y avoir accès, veuillez suivre ces étapes.

Premièrement, vous devrez appuyer sur 'Extraire tout' en haut de l'écran et choisir le chemin de votre bureau.

Ouvrez le nouveau dossier sur votre bureau.

Ouvrez le fichier 'MSelfbotV1' avec Visual Studio Code.

Ensuite, vous aurez le script. Veuillez simplement integrer votre token, votre id et votre préfix aux endroit désignés!

Enrigistré vos modifications et fermez Visual Studio Code.

Ensuite de cela, il vous suffira seulement de cliquer sur la barre en haut de l'écrant et modifier le chemin par 'cmd'.

Écrivez seulement 'cmd'. Ensuite, appuyez sur enter.

Quand cela sera fait, veuillez entrer 'node MSelfV1' dans l'invite de commande.

Ensuite, vous pourrez profiter de votre selfbot!

Les commandes principales sont : (Votre préfix)help et (Votre préfix)info

Veuillez ne pas fermer l'invite de commande durant que vous utilisez le selfbot!

Merci encore!

PS: Quand vous allez activer le bot, nous ne serons plus résponsable de ce que vous faites avec celui-ci. C'est à vos risques et périles!
